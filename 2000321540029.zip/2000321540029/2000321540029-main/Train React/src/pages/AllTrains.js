import React, { useEffect, useState } from "react";
import TrainCard from "../components/TrainCard";
import { Container, Typography, Grid } from "@mui/material";
import axios from "axios";

const AllTrains = () => {
  const [trains, setTrains] = useState([]);

  useEffect(() => {
    // Fetch all trains using API call here
    axios
      .get("http://20.244.56.144/train/trains")
      .then((response) => setTrains(response.data))
      .catch((error) => console.error("Error fetching trains:", error));
  }, []);

  // Filter trains departing in the next 30 minutes
  const filteredTrains = trains.filter(
    (train) => train.delayedBy <= 30 && train.departureTime.Hours === new Date().getHours()
  );

  // Sort trains based on the specified criteria
  const sortedTrains = filteredTrains.sort((a, b) => {
    if (a.price.AC === b.price.AC) {
      if (a.seatsAvailable.sleeper === b.seatsAvailable.sleeper) {
        return b.departureTime.Minutes - a.departureTime.Minutes;
      }
      return b.seatsAvailable.sleeper - a.seatsAvailable.sleeper;
    }
    return a.price.AC - b.price.AC;
  });

  return (
    <Container>
      <Typography variant="h4" mt={2}>
        All Trains
      </Typography>
      <Grid container spacing={2}>
        {sortedTrains.map((train) => (
          <Grid item xs={12} md={6} key={train.trainNumber}>
            <TrainCard train={train} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default AllTrains;
