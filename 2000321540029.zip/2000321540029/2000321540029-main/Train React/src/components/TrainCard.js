import React from "react";
import { Card, CardContent, Typography, Grid } from "@mui/material";

const TrainCard = ({ train }) => {
  return (
    <Card>
      <CardContent>
        <Typography variant="h6">{train.trainName}</Typography>
        <Typography>Train Number: {train.trainNumber}</Typography>
        <Typography>Departure Time: {train.departureTime.Hours}:{train.departureTime.Minutes}</Typography>
        <Typography>Sleeper Seats Available: {train.seatsAvailable.sleeper}</Typography>
        <Typography>AC Seats Available: {train.seatsAvailable.AC}</Typography>
        <Typography>Sleeper Price: {train.price.sleeper}</Typography>
        <Typography>AC Price: {train.price.AC}</Typography>
        <Typography>Delay: {train.delayedBy} minutes</Typography>
      </CardContent>
    </Card>
  );
};

export default TrainCard;
