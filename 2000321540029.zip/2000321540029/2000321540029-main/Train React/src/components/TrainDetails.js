import React from "react";
import { useParams } from "react-router-dom";
import { Typography, Box } from "@mui/material";

const TrainDetails = () => {
  const { trainNumber } = useParams();

  // Fetch train details using API call here

  return (
    <Box mt={2}>
      <Typography variant="h4">Train Details - {trainNumber}</Typography>
      {/* Display train details here */}
    </Box>
  );
};

export default TrainDetails;
