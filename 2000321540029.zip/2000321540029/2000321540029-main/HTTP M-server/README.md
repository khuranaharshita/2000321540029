# Output

![Output](https://github.com/HyperWoo/2000321540027/assets/114022709/7d004f99-bc73-4e32-8ea5-e5db857a58ba)
